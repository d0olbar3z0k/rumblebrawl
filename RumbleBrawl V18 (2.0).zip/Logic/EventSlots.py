import time, json, random

class EventSlots:

    def loadEvents(self):
    	with open("JSON/events.json", "r") as f:
    		data=json.load(f)
    		return data

    def loadNewEvents(self):
    	with open("JSON/new_events.json", "r") as f:
    		data=json.load(f)
    		return data

    def Timer(self):
        result = time.localtime(int(time.time()))

        return (86400 - (result.tm_sec + (result.tm_min * 60) + (result.tm_hour * 3600)))

    def offset(self):
        events = EventSlots.loadEvents(self)
        Timer = EventSlots.Timer(self)

        count = len(events)
        self.writeVint(count)

        maps = events.values()

        for event in maps:

            self.writeVint(list(maps).index(event) + 1)
            self.writeVint(list(maps).index(event) + 1)
            self.writeVint(0)  # IsActive | 0 = Active, 1 = Disabled
            self.writeVint(Timer)  # Timer

            self.writeVint(event['Tokens'])
            self.writeScId(15, event["ID"])

            if self.player.low_id in event["Collected"]:
                self.writeVint(2)
            else:
                self.writeVint(1)

            self.writeString() # "Double Experience Event" Text
            self.writeVint(0)

            if event['Modifier'] > 0:
                self.writeBoolean(True)
                self.writeVint(1)
            else:
                self.writeBoolean(False)

            self.writeVint(0)

    def newOffset(self):
        events = EventSlots.loadNewEvents(self)
        Timer = EventSlots.Timer(self)

        count = len(events)
        self.writeVint(count)

        maps = events.values()

        for event in maps:

            self.writeVint(list(maps).index(event) + 1)
            self.writeVint(list(maps).index(event) + 1)
            self.writeVint(Timer)  # IsActive | 0 = Active, 1 = Disabled
            self.writeVint(Timer)  # Timer

            self.writeVint(event['Tokens'])
            self.writeScId(15, event["ID"])

            self.writeVint(2)

            self.writeString() # "Double Experience Event" Text
            self.writeVint(0)

            if event['Modifier'] > 0:
                self.writeBoolean(True)
                self.writeVint(1)
            else:
                self.writeBoolean(False)

            self.writeVint(0)