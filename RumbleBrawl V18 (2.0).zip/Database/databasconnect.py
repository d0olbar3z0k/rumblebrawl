import pymysql

def get_db_path():
    return pymysql.connect(
  host=('127.0.0.1'),
  user=("newuser"),
  password=("neud3rzh1my"),
  database=('rumblebrawl')) #твой путь

def get_club_id(low_id):
 return