from Database.DatabaseManager import DataBase

from Utils.Reader import BSMessageReader

class Upgrade_Brawler(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()                  # csvID
        self.BrawlerID = self.read_Vint() # BrawlerID
        self.player.Brawler_level[str(self.BrawlerID)] = self.player.Brawler_level[str(self.BrawlerID)]


    def process(self):
        if self.player.Brawler_level[str(self.BrawlerID)] == 0:
        	self.player.gold -= 20
        	DataBase.replaceValue(self, 'gold', self.player.gold)
        	
        if self.player.Brawler_level[str(self.BrawlerID)] == 1:
        	self.player.gold -= 35
        	DataBase.replaceValue(self, 'gold', self.player.gold)
        	
        if self.player.Brawler_level[str(self.BrawlerID)] == 2:
        	self.player.gold -= 75
        	DataBase.replaceValue(self, 'gold', self.player.gold)
        	
        if self.player.Brawler_level[str(self.BrawlerID)] == 3:
        	self.player.gold -= 140
        	DataBase.replaceValue(self, 'gold', self.player.gold)
        	
        if self.player.Brawler_level[str(self.BrawlerID)] == 4:
        	self.player.gold -= 290
        	DataBase.replaceValue(self, 'gold', self.player.gold)
        	
        if self.player.Brawler_level[str(self.BrawlerID)] == 5:
        	self.player.gold -= 480
        	DataBase.replaceValue(self, 'gold', self.player.gold)
        	
        if self.player.Brawler_level[str(self.BrawlerID)] == 6:
        	self.player.gold -= 800
        	DataBase.replaceValue(self, 'gold', self.player.gold)
        	
        if self.player.Brawler_level[str(self.BrawlerID)] == 7:
        	self.player.gold -= 1250
        	DataBase.replaceValue(self, 'gold', self.player.gold)

        self.player.Brawler_level[str(self.BrawlerID)] += 1
        DataBase.replaceValue(self, 'brawlerPowerLevel', self.player.Brawler_level)