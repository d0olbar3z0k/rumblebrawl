
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
import random
import time
import threading

class LobbyInfoMessage(Writer):

    def __init__(self, client, player, count):
        super().__init__(client)
        self.id = 23457
        self.player = player
        self.count = count
        self.ping = random.randrange(21, 98)
        self.running = True
        self.update_thread = threading.Thread(target=self.update_ping)
        self.update_thread.start()

    def update_ping(self):
        while self.running:
            self.ping = random.randrange(21, 98)
            time.sleep(4)

    def stop(self):
        self.running = False
        self.update_thread.join()

    def encode(self):
        self.writeVint(self.count)
        self.writeString(f"<cff0019>E<cff0032>l<cff004c>d<cff0065>e<cff007f>s<cff0098>t<cff00b2> <cfe00cb>B<cff00e5>r<cff00fe>a<cff00ff>w<ce500ff>l<ccc00ff> <cb200ff>1<c9900ff>8<c7f00ff><c6600ff><c4c00ff><c3300fe></c>\nTG: <cff00ff>@</c>eldestservers\nYour ID: {self.player.low_id}")

        self.writeVint(1) # array
        for x in range(0):
            self.writeVint(1)
            self.writeVint(1)
            self.writeVint(1)
            self.writeVint(1)
            self.writeVint(1)