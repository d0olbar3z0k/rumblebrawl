from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class  GetLeaderboardClubGlobalOkMessage(Writer):

    def __init__(self, client, player, type):
        super().__init__(client)
        self.id = 24403
        self.player = player
        self.type = type
        self.count = 100


    def encode(self):
        self.indexOfClub = 0
        self.writeVint(2)
        self.writeVint(0)
        self.writeVint(0)
        self.writeString()

        DataBase.CountClub(self)

        def by_trophy(club):
            print(club)
            pon = int(club['trophies'])
            return pon

        self.writeVint(self.count)
        self.club_data.sort(key = by_trophy, reverse=True)

        for club in self.club_data:
            if club["clubID"] == self.player.club_low_id:
                self.indexOfClub = self.club_data.index(club) + 1
            DataBase.loadClub(self, club['clubID'])
            self.writeVint(0)
            self.writeVint(club['clubID'])

            self.writeVint(1)
            self.writeVint(club[1])
            self.writeVint(2)

            self.writeString(club[2])
            self.writeVint(club[3])

            self.writeVint(8)
            self.writeVint(club[4]) #what?


        self.writeVint(0)
        self.writeVint(self.indexOfClub)
        self.writeVint(0)
        self.writeVint(0)

        self.writeString(self.player.region)


