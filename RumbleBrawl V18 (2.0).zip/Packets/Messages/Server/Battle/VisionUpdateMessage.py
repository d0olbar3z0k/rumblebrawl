from Utils.Writer import Writer
from Utils.BitStream import BitStream
from Database.DatabaseManager import DataBase
from Logic.Player import Players
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
import random
import time
#import BitStream

class VisionUpdateMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24109
        self.player = player

    def encode(self):
        self.writeVint(0) # Battle Ticks
        self.writeVint(0)
        self.writeVint(0) # Commands Count
        self.writeVint(0) #viewers