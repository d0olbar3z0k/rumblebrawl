from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class BattleTestMessage(Writer):

    def __init__(self, client, player, players):
        super().__init__(client)
        self.id = 20405
        self.player = player
        self.players = players

    def encode(self):
        self.writeInt(20) # timer
        self.writeInt(self.players)  # Current player
        self.writeInt(self.player.mmplayers) # Max player
        self.writeInt(1) # Play Again Accepted Players
        self.writeInt(0) # Play Again Maximum Players
        self.writeBoolean(False) # Matchmake Timer Enabled State