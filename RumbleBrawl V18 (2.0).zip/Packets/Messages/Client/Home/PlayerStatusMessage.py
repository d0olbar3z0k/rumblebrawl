from Utils.Reader import BSMessageReader
from Database.DatabaseManager import DataBase


class PlayerStatusMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.status = self.read_Vint()

    def process(self):
        DataBase.replaceValue(self, "online", self.status)