from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.AllianceBot.Alliance_Bot_Chat_Server_Message import AllianceBotChatServerMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
import time
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Database.DatabaseManager import DataBase
from Database.DevMessage import DevMessage
from Utils.Reader import BSMessageReader
import tracemalloc
import json
import sqlite3 as sql
import base64, datetime
from Database.sqlDB import VIPDB
tracemalloc.start()


class AllianceChatMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.bot_msg = ''
        self.send_ofs = False
        self.IsAcmd = False
    def decode(self):
        self.msg = self.read_string()
        self.args = self.msg.strip().split()
        self.command=self.args[0]
        self.room_id = self.read_Vint()
#        if self.command=="/link":
#        	self.IsAcmd=True
#        	if self.player.link == 0:
#        		self.bot_msg=f"Твой lowID: {self.player.low_id}"
#        	elif self.player.link == 1 and self.player.link2!=0:
#        		self.player.link = 2
#        		DataBase.replaceValue(self, "link", 2)
#        		self.bot_msg="Отлично ты привязал свой аккаунт!"
#        		self.send_ofs=True
#        	elif self.player.link==2 and self.player.link2:
#        		self.bot_msg="Твой аккаунт уже привязан!"
#        	else:
#        		self.player.link=0
#        		DataBase.replaceValue(self, "link", 0)
        if self.command == "/theme":
        	self.IsAcmd=True
        	if self.player.vip:
        		if len(self.args)==2:
        			self.args[1] = int(self.args[1])
        			if self.args[1] > -1 and self.args[1] < 26 and self.args[1] != 5:
        				DataBase.replaceValue(self, 'theme', self.args[1])
        				self.send_ofs=True
        			else:
        				self.bot_msg="Указанного фона не существует!"
        		else:
        			self.bot_msg="Укажите айди темы!\nВсе доступные темы:\n0 - Дефолт тема\n1 - LNY\n2 -  Golden Week (фон с собаками)\n3 - Ретрополис\n4 - Меха\n6 - Фон с пиратами\n7 - LNY20 (Аркадное обновление)\n8 - PSG\n9 - SC10 (10 лет supercell)\n10 - Базар тары\n11 - Суперсити\n12 - Старр парк\n13 - Лунный фестиваль\n14 - Мировой финал 2020\n15 - Хэллоуин 2020\n16 - Зимний фон (Веселые каникулы)\n17 - Зимний фон (с партиклами)\n18 - Коспоопера старр\n19 - LNY21\n20 - ActionShow\n21 - Ramadan\n22 - Дефолт тема\n23 - Пляж\n24 - Punk\n25 - ColetteBrawl [Custom]"
        	else:
        		self.bot_msg = "У вас нет VIP!"
        elif self.command == "/help":
        		self.IsAcmd=True
        		self.bot_msg=f"Команды:\n==Для обычных игроков==\n/info - информация о вашем аккаунте\n/roomjoin - подключиться к рандомной руме\n/clubname [имя] - изменить имя клуба\n===VIP===\n/theme [ID] - сменить фон"
        		
        elif self.command == "/roomjoin":
        		self.IsAcmd=True
        		self.bot_msg=f"Поиск"
        		try:
        			DataBase.replaceValue(self, "roomID", self.room_id)
        			DataBase.getRoomAndJoin(self, self.token, self.player.room_id)
        			DataBase.loadGameroom(self)
        			if self.playerCount >= 3:
        				self.player.room_id = 0
        				DataBase.replaceValue(self, "roomID", 0)
        				DataBase.leaveRoom(self, self.player.low_id)
        				self.player.err_code=1
        				LoginFailedMessage(self.client, self.player, "Данная команда заполнена!").send()
        			else:
        				for i in self.plrData:
        					TeamGameroomDataMessage(self.client, self.player).sendWithLowID(self.plrData[i]["lowID"])
        		except:
        			self.player.err_code=1
        			LoginFailedMessage(self.client, self.player, "дрочил? это окно выходит только у дрочунах!").send()
        		
        elif self.command=="/debug":
        	if self.player.vip == 1:
        	    DevMessage(self.client, self.player).send()

        elif self.command=="/info":
        	self.IsAcmd=True
        	self.bot_msg=f"Name: {self.player.name}\ntrophies: {self.player.trophies}\nvip: {self.player.vip}\nlowID: {self.player.low_id}\nToken: {self.player.token}"
        	
        elif self.command == "/getvip":
            vipcodes = ['huy', 'skotina']
            code = self.msg.split("", 10)[1:0]
            code = " ".join(code)
            if code in vipcodes and self.player.vip != True:
                self.bot_msg = "Вип активирован"
                DataBase.replaceValue(self, vip, True)
            else:
                self.bot_msg = "Иди нахуй и обратись к @spermadev за випкой"
        
    def process(self):
        
        if self.send_ofs == False and self.IsAcmd == False:
            DataBase.Addmsg(self, self.player.club_low_id, 2, 0, self.player.low_id, self.player.name, self.player.club_role, self.msg)
            DataBase.loadClub(self, self.player.club_low_id)
            for i in self.plrids:
                AllianceChatServerMessage(self.client, self.player, self.msg, self.player.club_low_id).sendWithLowID(i)
                #AllianceStreamMessage(self.client, self.player, self.player.club_low_id, 0).send()

        if self.bot_msg != '':
            AllianceChatServerMessage(self.client, self.player, self.msg, self.player.club_low_id, True).send()
            AllianceBotChatServerMessage(self.client, self.player, self.bot_msg).send()

        if self.send_ofs:
            LoginFailedMessage(self.client, self.player, 'Для сохранения изменений вам нужно перезайти!').send()