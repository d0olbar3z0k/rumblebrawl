from Utils.Reader import BSMessageReader
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Database.DatabaseManager import DataBase
from Utils.Helpers import Helpers

class TeamJoinMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.roomType = self.read_Vint()
        self.room_id = self.read_Vint()

    def process(self):
        for room in Helpers.rooms:
            if room['roomID'] == self.room_id:
                if self.roomType == 0:
                    if len(room['plrs']) == 3:
                        pass
                    else:
                        new_player = {'id': self.player.low_id, 'name': self.player.name, 'brawlerID': self.player.brawler_id, 'skinID': self.player.skin_id, 'isOwner': 0, 'state': self.player.online}
                        room['plrs'].append(new_player)
                        self.player.room_id = self.room_id
                        print("done")
                        DataBase.replaceValue(self, 'roomID', self.player.room_id)
                        for i in room['plrs']:
                            TeamGameroomDataMessage(self.client, self.player).sendWithLowID(i["id"])
                else:
                    if len(room['plrs']) == 10:
                        pass
                    else:
                        new_player = {'id': self.player.low_id, 'name': self.player.name, 'brawlerID': self.player.brawler_id, 'skinID': self.player.skin_id, 'isOwner': 0, 'state': self.player.online}
                        room['plrs'].append(new_player)
                        self.player.room_id = self.room_id
                        print("done")
                        DataBase.replaceValue(self, 'roomID', self.player.room_id)
                        for i in room['plrs']:
                            TeamGameroomDataMessage(self.client, self.player).sendWithLowID(i["id"])
            break