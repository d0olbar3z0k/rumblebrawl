from Utils.Reader import BSMessageReader
from Logic.EventSlots import EventSlots
from Logic.Battle.Battle import Battle
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage


class OnPlay(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.MapIndex = self.read_Vint()

    def process(self):
        data = EventSlots.loadEvents(self)
        self.player.map_id = data[str(self.MapIndex - 1)]['ID']
        if self.MapIndex in [1, 3, 4]:
            self.player.mmplayers = 1
        if self.MapIndex in [2, 5]:
            self.player.mmplayers = 1
        if self.MapIndex == 6:
            self.player.mmplayers = 1
        #battle = Battle(self.client, self.player, 0)
        #battle.start()
        self.player.err_code = 1
        LoginFailedMessage(self.client, self.player, "Зайди в дружеский бой и играй там.").send()