-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Июл 11 2024 г., 11:58
-- Версия сервера: 8.0.37-0ubuntu0.20.04.3
-- Версия PHP: 7.4.3-4ubuntu2.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `rumblebrawl`
--

-- --------------------------------------------------------

--
-- Структура таблицы `players`
--

CREATE TABLE `players` (
  `id` int NOT NULL,
  `token` char(200) DEFAULT NULL,
  `name` char(200) DEFAULT NULL,
  `leagueReward` int DEFAULT NULL,
  `lowID` int DEFAULT NULL,
  `vip` int DEFAULT NULL,
  `clubID` int DEFAULT NULL,
  `clubRole` int DEFAULT NULL,
  `playerExp` int DEFAULT NULL,
  `soloWins` int DEFAULT NULL,
  `duoWins` int DEFAULT NULL,
  `TvsTWins` int DEFAULT NULL,
  `gems` int DEFAULT NULL,
  `gold` int DEFAULT NULL,
  `tokensdoubler` int DEFAULT NULL,
  `battleTokens` int DEFAULT NULL,
  `tickets` int DEFAULT NULL,
  `brawlerID` int DEFAULT NULL,
  `skinID` int DEFAULT NULL,
  `trophies` int DEFAULT NULL,
  `highest_trophies` int DEFAULT NULL,
  `profileIcon` int DEFAULT NULL,
  `namecolor` int DEFAULT NULL,
  `brawlBoxes` int DEFAULT NULL,
  `bigBoxes` int DEFAULT NULL,
  `starpower` int DEFAULT NULL,
  `DoNotDistrub` int DEFAULT NULL,
  `roomID` int DEFAULT NULL,
  `brawlersSkins` json DEFAULT NULL,
  `brawlersTrophies` json DEFAULT NULL,
  `brawlersTrophiesForRank` json DEFAULT NULL,
  `brawlersUpgradePoints` json DEFAULT NULL,
  `brawlerPowerLevel` json DEFAULT NULL,
  `brawlerStarPower` json DEFAULT NULL,
  `UnlockedBrawlers` json DEFAULT NULL,
  `UnlockedSkins` json DEFAULT NULL,
  `Friends` json DEFAULT NULL,
  `online` int DEFAULT NULL,
  `Notifications` char(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `promo` json DEFAULT NULL,
  `notifgems` int NOT NULL DEFAULT '0',
  `titul` char(200) NOT NULL DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `players`
--
ALTER TABLE `players`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1442;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
