import json
import random

class OfferGenerator:
	def loadOffers(self):
		try:
			with open("JSON/offers.json", "r") as f:
				data = json.load(f)
				return data
		except FileNotFoundError:
			return {}

	def generateOffers(self):
		result = {}

		# Daily small box offer
		l = str(len(result))
		result[l] = {
			"ID": 0,
			"OfferTitle": "DAILY",
			"Cost": 0,
			"OldCost": 0,
			"Multiplier": 1,
			"BrawlerID": 0,
			"SkinID": 0,
			"WhoBuyed": [],
			"ShopType": 1,
			"ShopDisplay": 1
		}

	    # Random special offer
		special_offer = random.choice([
			{"ID": 10, "OfferTitle": "ОСОБАЯ АКЦИЯ", "Cost": 49, "OldCost": 80, "Multiplier": 1, "BrawlerID": 0, "SkinID": 0, "WhoBuyed": [], "ShopType": 0, "ShopDisplay": 0},
			{"ID": 14, "OfferTitle": "ОСОБАЯ АКЦИЯ", "Cost": 19, "OldCost": 30, "Multiplier": 1, "BrawlerID": 0, "SkinID": 0, "WhoBuyed": [], "ShopType": 0, "ShopDisplay": 0},
			{"ID": 1, "OfferTitle": "ОСОБАЯ АКЦИЯ", "Cost": 59, "OldCost": random.randrange(100, 200), "Multiplier": random.randrange(1000, 5000), "BrawlerID": 0, "SkinID": 0, "WhoBuyed": [], "ShopType": 0, "ShopDisplay": 0}
		])
		l = str(len(result))
		result[l] = special_offer

	    # Brawler offers
		brawler_offers = [
			(4, 79), (11, 169), (12, 299), (5, 299), (17, 119), (21, 169), (23, 299),
			(6, 29), (13, 29), (15, 119), (16, 119), (18, 79), (19, 119), (20, 119),
			(24, 29), (25, 79), (26, 119)
		]
		random.shuffle(brawler_offers)
		for i in range(2):  # 2 brawler offers
			brawler_id, cost = brawler_offers[i]
			l = str(len(result))
			result[l] = {
				"ID": 3,
				"OfferTitle": "ЕЖЕДНЕВНАЯ АКЦИЯ",
				"Cost": cost-10,
				"OldCost": cost,
				"Multiplier": 1,
				"BrawlerID": brawler_id,
				"SkinID": 0,
				"WhoBuyed": [],
				"ShopType": 0,
				"ShopDisplay": 0
			}

	    # Skin offers
		skin_offers = [
			(29, 15), (15, 15), (79, 79), (2, 15), (25, 49), (64, 79),
			(44, 79), (58, 49), (91, 79), (57, 79), (28, 49), (30, 79), (71, 79),
			(27, 15), (92, 49), (26, 79), (68, 79), (88, 79), (93, 49),
			(45, 49), (50, 79), (75, 79), (11, 49), (20, 49), (49, 199)
		]
		random.shuffle(skin_offers)
		for i in range(3):  # 3 skin offers
			skin_id, cost = skin_offers[i]
			l = str(len(result))
			result[l] = {
				"ID": 4,
				"OfferTitle": "ЕЖЕДНЕВЫНЙ СКИН",
				"Cost": cost-10,
				"OldCost": cost,
				"Multiplier": 1,
				"BrawlerID": 0,
				"SkinID": skin_id,
				"WhoBuyed": [],
				"ShopType": 0,
				"ShopDisplay": 0
			}

		# Power Points offers
		for _ in range(5):  # 5 power points offers
			l = str(len(result))
			cost = random.randint(1, 50)
			multiplier = random.randint(10, 100)
			result[l] = {
				"ID": 8,
				"OfferTitle": "POWERPOINTS",
				"Cost": cost,
				"OldCost": 0,
				"Multiplier": multiplier,
				"BrawlerID": random.randint(1, 26),
				"SkinID": 0,
				"WhoBuyed": [],
				"ShopType": 1,
				"ShopDisplay": 1
			}

		self.newOffers(result)

	def newOffers(self, result):
		with open("JSON/offers.json", "w") as f:
			json.dump(result, f, indent=4)

	def deleteOffers(self):
		with open("JSON/offers.json", "r") as f:
			data = json.load(f)

		target_value = ["POWERPOINTS", "ЕЖЕДНЕВНАЯ АКЦИЯ", "DAILY", "ЕЖЕДНЕВЫНЙ СКИН"]
		for key, item in data.items():
			if item.get('OfferTitle') == target_value:
				data.items.remove(item)


		with open("JSON/offers.json", "w") as f:
			json.dump(data, f, indent=4)

	def updateOffers(self):
		self.deleteOffers()
		self.generateOffers()

#offer_generator = OfferGenerator()
#offer_generator.updateOffers()