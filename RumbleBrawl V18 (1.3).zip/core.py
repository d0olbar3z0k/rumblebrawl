import telebot
import socket
from telebot import types
import sqlite3
from Database.databasconnect import get_db_path
import re
import pymysql
import requests
from Utils.OfferGenerator import OfferGenerator
       
print("[Rumble Connect] | Бот запущен")

tecnobot = '7183296241:AAH-lqtVDzFd8rXc6ATb4c_eOUAB5E9rwTk'

SERVER_IP = 'eh' #ip
SERVER_PORT = 9339 #port
YM_TOKEN = 'да нету у менч его нахуй'
YM_WALLET_ID = 'pon'

#меняй на свой

bot = telebot.TeleBot(tecnobot)

admin=[7020402295]

@bot.message_handler(commands=['start'])
def send_welcome(message):
    markup = types.InlineKeyboardMarkup()
    btn1 = types.InlineKeyboardButton("Привязать аккаунт", callback_data="connect_account")
    btn2 = types.InlineKeyboardButton("Отвязать аккаунт", callback_data="delete_account")
    btn3 = types.InlineKeyboardButton("Ваши аккаунты", callback_data="show_accounts")
    btn4 = types.InlineKeyboardButton("Восстановить аккаунт", callback_data='restore')
    donat = types.InlineKeyboardButton("Купить донат", callback_data='buy_donation')
    markup.add(btn1, btn2, btn3, btn4, donat)
    bot.send_message(message.chat.id, "💕 | Привет!\n\nВ этом боте ты сможешь привязать аккаунт в Rumble Brawl или же купить донат!", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "connect_account")
def request_low_id(call):
    msg = bot.send_message(call.message.chat.id, "👏 | Здравствуй, для привязки напиши свой ID, его ты можешь найти в клубе по команде /info либо в главном меню.")
    bot.register_next_step_handler(msg, receive_low_id, call.message.chat.id, msg.message_id)

# Обработчик для ввода low_id
def receive_low_id(message, chat_id, message_id):
    try:
        player_id = int(message.text)
    except ValueError:
        msg = bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text="❌ | Вы ввели неправильный ID\n\n👾Введите ID еще раз"
        )
        bot.register_next_step_handler(message, receive_low_id, chat_id, msg.message_id)
        return

    try:
        user_id = message.from_user.id

        bot_db_connection = sqlite3.connect('Database/BotUser/users.db')
        bot_db_cursor = bot_db_connection.cursor()

        bot_db_cursor.execute('''CREATE TABLE IF NOT EXISTS accountconnect 
                                (lowID INTEGER PRIMARY KEY, trophies INTEGER, name TEXT, id_user INTEGER)''')
        bot_db_connection.commit()

        bot_db_cursor.execute("SELECT lowID, trophies, name FROM accountconnect WHERE id_user = ?", (user_id,))
        result = bot_db_cursor.fetchone()

        if result:
            bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text="❌ | Ошибка, аккаунт уже привязан"
            )
            return

        # Функция для подключения к серверной базе данных
        server_db_connection = get_mysql_connection()
        server_db_cursor = server_db_connection.cursor()

        server_db_cursor.execute("SELECT lowID, trophies, name FROM players WHERE lowID = %s", (player_id,))
        result = server_db_cursor.fetchone()

        if result:
            bot_db_cursor.execute("INSERT INTO accountconnect VALUES (?, ?, ?, ?)", (*result, user_id))
            bot_db_connection.commit()
            bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=f"❗ | Аккаунт с ID: {player_id} привязан успешно!\n\n👾 | Никнейм: {result[2]}\n\n❗ | Если это не ваш аккаунт, пожалуйста нажмите «Отвязать аккаунт» в главном меню."
            )
        else:
            bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text="❌ | Аккаунт с таким ID не существует!"
            )

    except Exception as e:
        bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=f"❓ | Ошибка: {str(e)}"
        )

    finally:
        bot_db_connection.close()
        if 'server_db_connection' in locals():
            server_db_connection.close()

@bot.callback_query_handler(func=lambda call: call.data == "delete_account")
def confirm_delete_account(call):
    markup = types.InlineKeyboardMarkup()
    btn_yes = types.InlineKeyboardButton("✅ | Да", callback_data="confirm_delete")
    markup.add(btn_yes)
    bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id,
                          text="⚠️ | Вы точно хотите отвязать аккаунт?\n\n❗ | Для отмены напишите /start", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "confirm_delete")
def delete_account(call):
    try:
        user_id = call.from_user.id

        bot_db_connection = sqlite3.connect('Database/BotUser/users.db')
        bot_db_cursor = bot_db_connection.cursor()

        bot_db_cursor.execute("DELETE FROM accountconnect WHERE id_user = ?", (user_id,))
        bot_db_connection.commit()

        bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id,
                              text="✅ | Ваш аккаунт был успешно отвязан.")
    except Exception as e:
        bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id,
                              text=f"❌ | Ошибка: {str(e)}")
    finally:
        bot_db_connection.close()

# Обработчик для нажатия кнопки "Ваши аккаунты"
@bot.callback_query_handler(func=lambda call: call.data == "show_accounts")
def show_accounts(call):
    try:
        user_id = call.from_user.id

        bot_db_connection = sqlite3.connect('Database/BotUser/users.db')
        bot_db_cursor = bot_db_connection.cursor()

        bot_db_cursor.execute("SELECT lowID, trophies, name FROM accountconnect WHERE id_user = ?", (user_id,))
        accounts = bot_db_cursor.fetchall()

        if accounts:
            accounts_info = "\n".join([f"ID: {account[0]}\nКубки: {account[1]}\nНик: {account[2]}" for account in accounts])
            bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id,
                                  text=f"🃏 | Привязанные аккаунты:\n{accounts_info}")
        else:
            bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id,
                                  text="⚠️ | У вас нет привязанных аккаунтов.")
    except Exception as e:
        bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id,
                              text=f"❌ Ошибка при получении аккаунтов: {str(e)}")
    finally:
        bot_db_connection.close()

@bot.callback_query_handler(func=lambda call: call.data == 'restore')
def restore_account_prompt(call):
    user_id = call.message.chat.id
    message_id = call.message.message_id

    bot.edit_message_text(chat_id=user_id, message_id=message_id, text="⚠️ | Напишите в лс @dolbarez0k\n/start")
    

def handle_token(message, message_id):
    user_id = message.chat.id
    new_token = message.text

    try:
        users_conn = sqlite3.connect('Database/BotUser/users.db')
        users_cursor = users_conn.cursor()

        users_cursor.execute("SELECT lowID FROM accountconnect WHERE id_user = ?", (user_id,))
        row = users_cursor.fetchone()

        if row:
            lowID = row[0]

            plr_conn_local = get_mysql_connection()
            plr_cursor_local = plr_conn_local.cursor()

            plr_cursor_local.execute("SELECT lowID FROM players WHERE token = %s", (new_token,))
            token_row = plr_cursor_local.fetchone()

            if token_row:
                lowID_to_delete = token_row[0]

                plr_cursor_local.execute("DELETE FROM players WHERE lowID = %s", (lowID_to_delete,))
                plr_conn_local.commit()

                plr_cursor_local.execute("UPDATE players SET token = %s WHERE lowID = %s", (new_token, lowID))
                plr_conn_local.commit()

                markup = types.InlineKeyboardMarkup()
                return_button = types.InlineKeyboardButton("Назад", callback_data='start')
                markup.add(return_button)

                bot.edit_message_text(chat_id=user_id, message_id=message_id, text="✅ | Токен успешно поменян!", reply_markup=markup)
            else:
                bot.edit_message_text(chat_id=user_id, message_id=message_id, text="❌ | Неправильный токен")
        else:
            bot.edit_message_text(chat_id=user_id, message_id=message_id, text="⚠️ | Для начала привяжите аккаунт!")

    except Exception as e:
        bot.edit_message_text(chat_id=user_id, message_id=message_id, text=f" {str(e)}")
    finally:
        users_conn.close()
        if 'plr_conn_local' in locals():
            plr_conn_local.close()

@bot.callback_query_handler(func=lambda call: call.data == 'buy_donation')
def show_donation_prices(call):
    
    
    bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id, text="Напишите в лс @dolbarez0k\n/start")

@bot.callback_query_handler(func=lambda call: call.data.startswith('donation_'))
def handle_donation_selection(call):
    donation_type = call.data.split('_')[1]
    payment_url = "https://yoomoney.ru/to/4100118653440295"

    messages = {
        'Rumble premium': f"Переведите по этой [ссылке]({payment_url}) 100₽. В комментариях укажите свой юзернейм в телеграме, ваш ID в игре и vip. Пример: @username 85800 vip\n\n❓ | Что дает премиум?\n1. Цветной ник(позже дополнится)",
        '30': f"Переведите по этой [ссылке]({payment_url}) 50₽. В комментариях укажите свой юзернейм в телеграме, ваш ID в игре и сколько гемов вы купили. Пример: @username 85800 30",
        '80': f"Переведите по этой [ссылке]({payment_url}) 100₽. В комментариях укажите свой юзернейм в телеграме, ваш ID в игре и сколько гемов вы купили. Пример: @username 85800 30",
        '170': f"Переведите по этой [ссылке]({payment_url}) 150₽. В комментариях укажите свой юзернейм в телеграме, ваш ID в игре и сколько гемов вы купили. Пример: @username 85800 30",
        '360': f"Переведите по этой [ссылке]({payment_url}) 200₽. В комментариях укажите свой юзернейм в телеграме, ваш ID в игре и сколько гемов вы купили. Пример: @username 85800 30",
        '950': f"Переведите по этой [ссылке]({payment_url}) 250₽. В комментариях укажите свой юзернейм в телеграме, ваш ID в игре и сколько гемов вы купили. Пример: @username 85800 30",
        '2000': f"Переведите по этой [ссылке]({payment_url}) 300₽. В комментариях укажите свой юзернейм в телеграме, ваш ID в игре и сколько гемов вы купили. Пример: @username 85800 30"
    }

    confirm_markup = types.InlineKeyboardMarkup()
    confirm_button = types.InlineKeyboardButton("Подтвердить оплату", callback_data=f'confirm_{donation_type}')
    confirm_markup.add(confirm_button)

    bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=messages[donation_type],
        reply_markup=confirm_markup,
        parse_mode='Markdown'
    )

@bot.callback_query_handler(func=lambda call: call.data.startswith('confirm_'))
def handle_payment_confirmation(call):
    bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text="💕 | Спасибо за покупку, ожидайте пока пройдет оплата\n\n⚠️ | Мы пришлем ваш заказ без оповещения!"
    )

@bot.callback_query_handler(func=lambda call: call.data == "start")
def go_to_start(call):
    user_id = call.message.chat.id
    message_id = call.message.message_id
    markup = types.InlineKeyboardMarkup()
    btn1 = types.InlineKeyboardButton("Привязать аккаунт", callback_data="connect_account")
    btn2 = types.InlineKeyboardButton("Отвязать аккаунт", callback_data="delete_account")
    btn3 = types.InlineKeyboardButton("Ваши аккаунты", callback_data="show_accounts")
    btn4 = types.InlineKeyboardButton("Восстановить аккаунт", callback_data='restore')
    btn4 = types.InlineKeyboardButton("Восстановить аккаунт", callback_data='restore')
    donat = types.InlineKeyboardButton("Купить донат", callback_data='buy_donation')
    markup.add(btn1, btn2, btn3, btn4, donat)
    bot.edit_message_text(chat_id=user_id, message_id=message_id, text="💕 | Привет!\n\nВ этом боте ты сможешь привязать аккаунт в Rumble Brawl или же купить донат!", reply_markup=markup)

  
@bot.message_handler(commands=['start11'])
def start(message):
    bot.reply_to(message, 'Добро пожаловать! \nвыберите действие\n\n/leaders - посмотреть топы\n/check_online\n/connect - привязать аккаунт\n/profile - посмотреть профиль\n/restore - восстановить аккаунт\n\nАдмин команды:\n/add_gems - выдать или забрать гемы\n/vip - выдать вип статут или забрать\n/name - выдать цветной ник\n/tokenbox - выдать токены\n/theme - поменять тему в меню\n/new_offer - добавить акцию') #твое собщение
    

        
@bot.message_handler(commands=['add_gems'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 3:
            bot.reply_to(message, "Правильное использование /add_gems ID AMOUNT")
        else:
            lowID = message.text.split()[1]
            amount = int(message.text.split()[2])
            try:
                conn = get_mysql_connection()
                cursor = conn.cursor()

                # Получить текущее количество гемов
                cursor.execute("SELECT gems FROM players WHERE lowID = %s", (lowID,))
                result = cursor.fetchone()
                
                if result:
                    current_gems = result[0]
                    new_gems = current_gems + amount

                    # Обновить количество гемов
                    cursor.execute("UPDATE players SET gems = %s WHERE lowID = %s", (new_gems, lowID))
                    conn.commit()

                    bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {lowID} добавлено {amount} гемов. Теперь у него {new_gems} гемов.")
                else:
                    bot.send_message(chat_id=message.chat.id, text=f"Игрок с айди {lowID} не найден.")

                cursor.close()
                conn.close()
            except Exception as e:
                bot.send_message(chat_id=message.chat.id, text=f"Произошла ошибка: {str(e)}")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

        
@bot.message_handler(commands=['vip'])
def add_vip(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 3:
            bot.reply_to(message, "Правильное использование /vip ID level")
        else:
            lowID = message.text.split()[1]
            level = message.text.split()[2]
            try:
                conn = get_mysql_connection()
                cursor = conn.cursor()
                cursor.execute("UPDATE players SET vip = %s WHERE lowID = %s", (level, lowID))
                conn.commit()
                cursor.close()
                conn.close()
                bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {lowID} выдан {level}-й уровень VIP.")
            except Exception as e:
                bot.send_message(chat_id=message.chat.id, text=f"Произошла ошибка: {str(e)}")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")
        
@bot.message_handler(commands=['theme'])
def theme(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Выбери ID темы\n0 - Обычная\n1 - Новый год (Снег)\n2 - Красный новый год\n3 - От клеш рояля\n5 - Желтые панды\n6 - Фиолетовый булл\n7 - Роботы Зелёный фон\nИспользовать команду /theme ID")
        else:
            user_id = message.from_user.id
            theme_id = message.text.split()[1]
            with open("Logic/theme.txt", "w") as f:
            	bot.send_message(chat_id=message.chat.id, text=f"Тема была изменена на {theme_id}")
            	f.write(theme_id)
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")        
        
@bot.message_handler(commands=['tokenboxggg'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /add_gems ID AMMOUNT")
        else:
            user_id = message.from_user.id
            id = message.text.split()[1]
            ammount = message.text.split()[2]
            conn = sqlite3.connect("Database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET brawlBoxes = ? WHERE lowID = ?", (ammount, id))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {id} Выдали {ammount} жетонов на маленкий ящик.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")                                                        

def get_mysql_connection():
    return get_db_path()

              
bot.infinity_polling()