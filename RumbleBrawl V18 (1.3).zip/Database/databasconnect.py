import pymysql

def get_db_path():
    return pymysql.connect(
  host=('IP MySQL'),
  user=("user MySQL"),
  password=("pass MySQL"),
  database=('database MySQL')) #твой путь

def get_club_id(low_id):
 return