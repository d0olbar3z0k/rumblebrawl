import json
import sqlite3 as sql
import os, datetime
import string
import pymysql
from Database.databasconnect import *
from Logic.Player import Players


class DataBase:

    def loadAccount(self):
        con = get_db_path()
        with con:    
            cur = con.cursor()
            cur.execute ('''CREATE TABLE IF NOT EXISTS players(
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
             token CHAR(200),
             `name` CHAR(200),
             `leagueReward` INT,
             `lowID` INT,
             `vip` INT,
             `clubID` INT,
             `clubRole` INT,
             `playerExp` INT,
             `soloWins` INT,
             `duoWins` INT,
             `TvsTWins` INT,
             `gems` INT,
             `gold` INT,
             `tokensdoubler` INT,
             `battleTokens` INT,
             `tickets` INT,
             `brawlerID` INT,
             `skinID` INT,
             `trophies` INT,
             `highest_trophies` INT,
             `profileIcon` INT,
             `namecolor` INT,
             `brawlBoxes` INT,
             `bigBoxes` INT,
             `starpower` INT,
             `DoNotDistrub` INT,
             `roomID` INT,
             `brawlersSkins` JSON,
             `brawlersTrophies` JSON,
             `brawlersTrophiesForRank` JSON,
             `brawlersUpgradePoints` JSON,
             `brawlerPowerLevel` JSON,
             `brawlerStarPower` JSON,
             `UnlockedBrawlers` JSON,
             `UnlockedSkins` JSON,
             `Friends` JSON,
             `online` INT,
             `Notifications` JSON,
             `notifgems` INT,
             `titul` CHAR(200)
             )''')
            cur.execute(f"SELECT * FROM players WHERE token = '{self.player.token}'") 
            rows = cur.fetchall()
            
            for row in rows:
                row_value = 0
                self.player.id =  row[row_value]
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.token =  row[row_value]
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.name =  row[row_value]
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.trophy_road =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.low_id =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.vip =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.club_low_id =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.club_role =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.player_experience =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.solo_wins =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.duo_wins =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.ThreeVSThree_wins =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.gems =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.gold =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.tokensdoubler =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.battle_tokens =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.tickets =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.brawler_id =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.skin_id =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.trophies =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.highest_trophies =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.profile_icon =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.name_color =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.brawl_boxes =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.big_boxes =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.starpower =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.do_not_distrub =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.room_id =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.brawlers_skins =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.brawlers_trophies =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.brawlers_trophies_in_rank =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.brawlers_upgradium =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.Brawler_level =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.Brawler_starPower =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.BrawlersUnlockedState =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.UnlockedSkins =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.Friends =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.online =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.Notifications =  row[row_value]
                row_newvalue = row_value + 2
                row_value = row_newvalue
                self.player.notifgems = int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.titul = row[row_value]
                row_newvalue = row_value + 1
                row_value = row_newvalue

            if self.player.trophies >= self.player.highest_trophies:
                self.player.highest_trophies = self.player.trophies
                DataBase.replaceValue(self, 'highest_trophies', self.player.highest_trophies)

    def createAccount(self):
        Players.CreateNewBrawlersList()
        con = get_db_path()
        with con.cursor() as cursor:
            cursor.execute ('''CREATE TABLE IF NOT EXISTS players (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            token CHAR(200),
            name CHAR(200),
            `leagueReward` INT,
            `lowID` INT,
            `vip` INT,
            `clubID` INT,
            `clubRole` INT,
            `playerExp` INT,
            `soloWins` INT,
            `duoWins` INT,
            `TvsTWins` INT,
            `gems` INT,
            `gold` INT,
            `tokensdoubler` INT,
            `battleTokens` INT,
            `tickets` INT,
            `brawlerID` INT,
            `skinID` INT,
            `trophies` INT,
            `highest_trophies` INT,
            `profileIcon` INT,
            `namecolor` INT,
            `brawlBoxes` INT,
            `bigBoxes` INT,
            `starpower` INT,
            `DoNotDistrub` INT,
            `roomID` INT,
            `brawlersSkins` JSON,
            `brawlersTrophies` JSON,
            `brawlersTrophiesForRank` JSON,
            `brawlersUpgradePoints` JSON,
            `brawlerPowerLevel` JSON,
            `brawlerStarPower` JSON,
            `UnlockedBrawlers` JSON,
            `UnlockedSkins` JSON,
            `Friends` JSON,
            `online` INT,
            `Notifications` JSON,
            `promo` JSON,
            `notifgems` INT
            )''')
            sql = f"""INSERT INTO `players` (
            `token`,
            `name`,
            `leagueReward`,
            `lowID`,
            `vip`,
            `clubID`,
            `clubRole`,
            `playerExp`,
            `soloWins`,
            `duoWins`,
            `TvsTWins`,
            `gems`,
            `gold`,
            `tokensdoubler`,
            `battleTokens`,
            `tickets`,
            `brawlerID`,
            `skinID`,
            `trophies`,
            `highest_trophies`,
            `profileIcon`,
            `namecolor`,
            `brawlBoxes`,
            `bigBoxes`,
            `starpower`,
            `DoNotDistrub`,
            `roomID`,
            `brawlersSkins`,
            `brawlersTrophies`,
            `brawlersTrophiesForRank`,
            `brawlersUpgradePoints`,
            `brawlerPowerLevel`,
            `brawlerStarPower`,
            `UnlockedBrawlers`,
            `UnlockedSkins`,
            `Friends`,
            `online`,
            `Notifications`,
            `promo`
            )
            VALUES (
            '{self.player.token}',
            '{self.player.name}',
            '{self.player.trophy_road}',
            '{self.player.low_id}',
            '{self.player.vip}',
            '{self.player.club_low_id}',
            '{self.player.club_role}',
            '{self.player.player_experience}',
            '{self.player.solo_wins}',
            '{self.player.duo_wins}',
            '{self.player.ThreeVSThree_wins}',
            '{self.player.gems}',
            '{self.player.gold}',
            '{self.player.tokensdoubler}',
            '{self.player.battle_tokens}',
            '{self.player.tickets}',
            '{self.player.brawler_id}',
            '{self.player.skin_id}',
            '{self.player.trophies}',
            '{self.player.highest_trophies}',
            '{self.player.profile_icon}',
            '{self.player.name_color}',
            '{self.player.brawl_boxes}',
            '{self.player.big_boxes}',
            '{self.player.starpower}',
            '{self.player.do_not_distrub}',
            '{self.player.room_id}',
            """ + """
            '{"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0}',
            '{"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0}',
            '{"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0}',
            '{"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0}',
            '{"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0}',
            '{"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0}',
            '{"0": 1, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0}',
            '{"Skins": []}',
            '{}',
            """ + f"""
            '{self.player.online}',
            """ + """
            'none',
            '{}'
            )"""
            cursor.execute(sql)
            cursor.execute('DELETE FROM players WHERE name = "DUDOZ"')
        con.commit()

    # Gameroom
    def createGameroomDB(self):
        self.conn = sql.connect("Database/gr.db")
        self.cur = self.conn.cursor()
        self.cur.execute("CREATE TABLE IF NOT EXISTS gr (roomID INT, mapID INT, PlayerCount JSON, roomType INT)")
        plrs = {"0": {"host": 1, "lowID": self.player.low_id, "name": self.player.name, "Team": self.player.team, "Ready": self.player.isReady, "brawlerID": self.player.brawler_id, "skinID": self.player.skin_id, "starpower": self.player.starpower, "profileIcon": self.player.profile_icon}}
        self.cur.execute("INSERT INTO gr VALUES (?,?,?,?)", (self.player.room_id, self.player.map_id, json.dumps(plrs), self.roomType))
        self.conn.commit()

    def loadGameroom(self):
        self.conn = sql.connect("Database/gr.db")
        self.cur = self.conn.cursor()
        self.cur.execute("SELECT * FROM gr WHERE roomID=?", (self.player.room_id,))
        fetch = self.cur.fetchall()
        if fetch:
            self.mapID = fetch[0][1]
            plrs = json.loads(fetch[0][2])
            self.playerCount = len(plrs)
            self.plrData = plrs
            self.roomType = fetch[0][3]

    def replaceGameroomValue(self, value_name, new_value, type):
        self.conn = sql.connect("Database/gr.db")
        self.cur = self.conn.cursor()
        self.cur.execute("SELECT * FROM gr WHERE roomID=?", (self.player.room_id,))
        fetch = self.cur.fetchall()
        if fetch:
        	if type=="room":
        		self.cur.execute(f"UPDATE gr SET {value_name}=? WHERE roomID=?", (new_value, self.player.room_id))
        		self.conn.commit()
        elif type == "player":
            gameroom_data["info"][str(value_name)] = new_value
            db.update(gameroom_data, query.room_id == self.player.room_id)
            plrData = json.loads(fetch[0][3])
            for i in plrData:
            	if i["lowID"]==self.player.low_id:
            		plrData[str(plrData.index(i))][str(value_name)]=new_value
            		self.cur.execute(f"UPDATE gr SET players=?", (json.dumps(plrData),))
            		self.conn.commit()
        elif type == "removePlayer":
            plrData = json.loads(fetch[0][3])
            for i in plrData:
            	if i["host"]==1:
            	   self.cur.execute("DELETE FROM gr WHERE roomID=?", (fetch[0][0],))
            	   self.conn.commit()

    def getRoomAndJoin(self, joinerToken, roomID):
    	self.conn = sql.connect("Database/gr.db")
    	self.cur = self.conn.cursor()
    	self.cur.execute("SELECT * FROM gr WHERE roomID=?", (roomID,))
    	fetch = self.cur.fetchall()
    	if fetch:
    		self.reqID = fetch[0][0]
    		plrsData = json.loads(fetch[0][2])
    		l = str(len(plrsData))
    		plrsData[l]={}
    		plrsData[l]["host"] = 0
    		plrsData[l]["lowID"] = self.player.low_id
    		plrsData[l]["name"] = self.player.name
    		plrsData[l]["Team"] = 0
    		plrsData[l]["Ready"] = self.player.isReady
    		plrsData[l]["brawlerID"] = self.player.brawler_id
    		plrsData[l]["skinID"] = self.player.skin_id
    		plrsData[l]["starpower"] = self.player.starpower
    		plrsData[l]["profileIcon"] = self.player.profile_icon
    		self.mapID = fetch[0][1]
    		self.playerCount = len(plrsData)
    		self.plrData = plrsData
    		self.cur.execute("UPDATE gr SET PlayerCount=? WHERE roomID=?", (json.dumps(plrsData), self.reqID))
    		self.conn.commit()

    def UpdateGameroomPlayerInfo(self, low_id):
        self.conn = sql.connect("Database/gr.db")
        self.cur = self.conn.cursor()
        self.cur.execute("SELECT * FROM gr WHERE roomID=?", (self.player.room_id,))
        fetch = self.cur.fetchall()
        if fetch:
        	plrsData = json.loads(fetch[0][2])
        	self.reqID = fetch[0][0]
        	for i in plrsData:
        		if plrsData[i]["lowID"]==low_id:
        			plrsData[i]["Team"] = self.player.team
        			plrsData[i]["Ready"] = self.player.isReady
        			plrsData[i]["brawlerID"] = self.player.brawler_id
        			plrsData[i]["skinID"] = self.player.skin_id
        			plrsData[i]["starpower"] = self.player.starpower
        			plrsData[i]["profileIcon"] = self.player.profile_icon
        			self.cur.execute("UPDATE gr SET PlayerCount=? WHERE roomID=?", (json.dumps(plrsData), self.reqID))
        			self.conn.commit()
        			self.conn.close()
        			break

    def replaceValue(self, value_name, new_value):
        con = get_db_path()
        with con.cursor() as cursor:
            if value_name in ["brawlersTrophies","brawlersTrophiesForRank","brawlersSkins","brawlerPowerLevel","brawlersUpgradePoints","UnlockedBrawlers","brawlerStarPower"]:
                cursor.execute(f"SELECT {value_name} FROM players WHERE token = '{self.player.token}'")
                zalupka = cursor.fetchall()
                data = json.loads(zalupka[0][0])
                data[value_name] = new_value
                new_data = json.dumps(data[value_name])
                sql = f"UPDATE `players` SET `{value_name}`= '{new_data}' WHERE token = '{self.player.token}'"
                print(sql)
                cursor.execute(sql)
            elif value_name == "UnlockedSkins":
                cursor.execute(f"SELECT {value_name} FROM players WHERE token = '{self.player.token}'")
                zalupka = cursor.fetchall()
                data = json.loads(zalupka[0][0])
                data[value_name] = new_value
                new_data = json.dumps(data[value_name])
                sql = f"UPDATE `players` SET `{value_name}`= '{new_data}' WHERE token = '{self.player.token}'"
                cursor.execute(sql)
            try:
                sql = f'UPDATE `players` SET `{value_name}`= "{new_value}" WHERE token = "{self.player.token}"'
                cursor.execute(sql)
            except Exception:
                pass
        con.commit()

    def replaceOtherValue(self, low_id, value_name, new_value):
        con = get_db_path()
        with con.cursor() as cursor:
            if value_name in ["brawlersTrophies","brawlersTrophiesForRank","brawlersSkins","brawlerPowerLevel","brawlersUpgradePoints","UnlockedBrawlers","brawlerStarPower"]:
                cursor.execute(f"SELECT {value_name} FROM players WHERE lowID = {low_id}")
                zalupka = cursor.fetchall()
                data = json.loads(zalupka[0][0])
                data[value_name] = new_value
                new_data = json.dumps(data[value_name])
                sql = f"UPDATE `players` SET `{value_name}`= '{new_data}' WHERE lowID = {low_id}"
                cursor.execute(sql)
            elif value_name == "UnlockedSkins":
                cursor.execute(f"SELECT {value_name} FROM players WHERE lowID = {low_id}")
                zalupka = cursor.fetchall()
                data = json.loads(zalupka[0][0])
                data[value_name] = new_value
                new_data = json.dumps(data[value_name])
                sql = f"UPDATE `players` SET `{value_name}`= '{new_data}' WHERE lowID = {low_id}"
                cursor.execute(sql)
            try:
                sql = f'UPDATE `players` SET `{value_name}`= "{new_value}" WHERE lowID = {low_id}'
                cursor.execute(sql)
            except Exception:
                pass
        con.commit()

    def DeleteTrash(self):
        con = get_db_path()
        try:
            with con.cursor() as cursor:
                cursor.execute('SELECT name FROM players WHERE name = "Guest"')
                count = cursor.fetchall()
                if len(count) >= 15:
                    cursor.execute('DELETE FROM players WHERE name = "Guest"')
                else:
                    pass
        except:
            pass
        con.commit()

    def fixAccount(self):
        DataBase.replaceValue(self, "trophies", 0)
        DataBase.replaceValue(self, "highest_trophies", 0)
        DataBase.replaceValue(self, "clubID", 0)
        DataBase.replaceValue(self, "gold", 100)
        DataBase.replaceValue(self, "gems", 0)
        DataBase.replaceValue(self, "tickets", 5)
        DataBase.replaceValue(self, "bigBoxes", 0)
        DataBase.replaceValue(self, "brawlBoxes", 0)
        DataBase.replaceValue(self, "tokensdoubler", 0)
        DataBase.replaceValue(self, "tgid", 0)
        DataBase.replaceValue(self, "playerExp", 0)
        self.player.brawlers_trophies[str(self.player.brawler_id)] = 0
        self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] = 0
        DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
        DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)

    def checkID(self, new_id):
        con = get_db_path()
        with con.cursor() as cursor:
            try:
                cursor.execute(f"SELECT lowID FROM `players` WHERE lowID = '{new_id}'")
                count = len(cursor.fetchall())
                if count == 0:
                    return 1
                else:
                    return 0
            except:
                return 1

    def getFriends(self):
        self.friendList = []
        index = []
        for i in self.player.Friends:
            index.append(i)
        for i in index[::-1]:
            if index[::-1].index(i)<=4:
                self.friendList.append(json.dumps(self.player.Friends[str(i)]))
        self.friendList.sort(reverse=False)
        return self.friendList

    def setFriendData(self, lowID):
        player = DataBase.loadAccount(self)
        friendData = json.loads(player[36])
        l = str(len(friendData))
        friendData[l] = {}
        friendData[l]["lowID"] = lowID
        new_data = json.dumps(friendData)
        DataBase.replaceValue(self, "Friends", new_data)

    def sendNotifData(self, lowID, ID, text, type):
        player = DataBase.loadById(self, lowID)
        notifData = json.loads(player[38])
        l = str(len(notifData))
        notifData[l] = {}
        notifData[l]["ID"] = ID
        notifData[l]["Index"] = 3
        notifData[l]["Read"] = False
        notifData[l]["Time"] = datetime.datetime.timestamp(datetime.datetime.now())
        notifData[l]["Text"] = text
        if ID == 81:
            notifData[l]["Type"] = type
        DataBase.replaceValue(self, "Notifications", notifData)

    def loadOldAccount(self, nost_id):
        con = get_db_path()
        with con.cursor() as cursor:
            cursor.execute(f"SELECT tgid FROM `players` WHERE tgid = '{nost_id}'")
            count = len(cursor.fetchall())
            if count != 0:
                cursor.execute(f'UPDATE `players` SET `token` = "{self.player.token}" WHERE tgid = {nost_id}')
            else:
                pass

    def replaceValues():
        con = get_db_path()
        with con.cursor() as cursor:
            cursor.execute("UPDATE `players` SET online = 0")
            cursor.execute("UPDATE `players` SET roomID = 0")
        con.commit()

    def getLeaders(self):
        con = get_db_path()
        with con.cursor() as cursor:
            cursor.execute("SELECT lowID, name, trophies, profileIcon, namecolor, clubID, vip, titul FROM `players` ORDER BY trophies DESC LIMIT 100")
            return cursor.fetchall()

    def loadById(self, ID):
        con = get_db_path()
        with con.cursor() as cursor:
            cursor.execute(f"SELECT * FROM `players` WHERE lowID = '{ID}'")
            return cursor.fetchall()

    def loadMembersById(self, ID):
        con = get_db_path()
        with con.cursor() as cursor:
            cursor.execute(f"SELECT * FROM `players` WHERE lowID = '{ID}'")
            return cursor.fetchone()

    # Club
    def createClub(self, clubid):
        self.conn = sql.connect("Database/clubs.db")
        self.con = sql.connect(f"Database/Chats/{clubid}.db")
        self.cur = self.conn.cursor()
        self.c = self.con.cursor()
        self.cur.execute(f"CREATE TABLE IF NOT EXISTS clubs (clubID INT, name TEXT, description TEXT, region TEXT, badgeID INT, type INT, trophiesneeded INT, trophies INT, members JSON, notif JSON)")
        self.c.execute(f"CREATE TABLE IF NOT EXISTS chats (Event INT, Tick INT, plrid INT, plrname TEXT, plrrole INT, Msg TEXT)")
        self.con.commit()
        self.conn.commit()
        data = {"members": {self.player.low_id:self.player.name}}
        notif = {}
        var = clubid,str(self.clubName),str(self.clubdescription),"RU",self.clubbadgeID,self.clubtype,self.clubtrophiesneeded,self.player.trophies,json.dumps(data),json.dumps(notif)
        self.cur.execute(f"INSERT INTO clubs VALUES (?,?,?,?,?,?,?,?,?,?)", var)
        self.conn.commit()
        msgData = {
            "clubID": clubid,
            "info": {
                "Total": 1,
                "1": {
                    "Event": 2,
                    "Tick": 1,
                    "PlayerID": self.player.low_id,
                    "PlayerName": self.player.name,
                    "PlayerRole": 2,
                    "Message": "Welcome to your new club!"
                }
            }
        }
        sss = "INSERT INTO chats VALUES (?, ?, ?,?,?,?)"
        var = 2, 1, self.player.low_id, str(self.player.name), 2, "Club Created!"
        self.c.execute(sss, var)
        self.con.commit()
        if str(self.clubName) == "лох":
            self.c.execute("DELETE FROM chats")
            self.cur.execute(f"DELETE FROM clubs WHERE clubID={clubid}")
            self.con.commit()
            self.conn.commit()
        else:
            pass

    def setNotifData(self, text, by):
    	self.conn = sql.connect("Database/clubs.db")
    	self.cur = self.conn.cursor()
    	self.cur.execute("SELECT * FROM clubs WHERE clubID=?", (self.player.club_low_id,))
    	fetch = self.cur.fetchall()
    	if fetch:
    	   	notifData = json.loads(fetch[0][9])
    	   	l = str(len(notifData))
    	   	notifData[l]={}
    	   	notifData[l]["text"]=text
    	   	notifData[l]["by"]=by
    	   	notifData[l]["timer"]=datetime.datetime.timestamp(datetime.datetime.now())
    	   	self.cur.execute("UPDATE clubs SET notif=? WHERE clubID=?", (json.dumps(notifData),self.player.club_low_id))
    	   	self.conn.commit()
    	   	self.conn.close()

    def CountClub(self):
        self.AllianceCount = 0
        self.club_list = []
        self.conn = sql.connect("Database/clubs.db")
        self.cur = self.conn.cursor()
        try:
                		self.cur.execute(f"SELECT * FROM clubs")
                		fetch = self.cur.fetchall()
                		if len(fetch)>0:
                			for i in fetch:
                				self.club_list.append(int(i[0]))
                				self.AllianceCount+=1
                		self.conn.close()
        except:
            pass

    def loadClub(self, clubid):
        self.conn = sql.connect("Database/clubs.db")
        self.cur = self.conn.cursor()
        
        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={clubid}")
        fetch = self.cur.fetchall()
        if len(fetch)>0:
        		for i in fetch:
        			self.clubmembercount = 0
        			self.plrids = []
        			self.clubName = i[1]
        			self.clubdescription = i[2]
        			self.clubregion = i[3]
        			
        			self.clubbadgeID = i[4]
        			self.clubtype = i[5]
        			self.clubtrophiesneeded = i[6]
        			try:
        				self.notifData = json.loads(i[9])
        			except:
        				self.cur.execute("ALTER TABLE clubs ADD COLUMN notif JSON")
        				self.conn.commit()
        			self.clubtrophies = 0
        			data = json.loads(i[8])
        			for ID in data["members"]:
        			     	if ID != "members":
        			     		self.plrids.append(int(ID))
        			     		self.clubmembercount += 1
        			     		DataBase.GetMemberData(self, int(ID))
        			     		self.clubtrophies += self.plrtrophies
        			#self.cur.execute(f"UPDATE clubs SET trophies={self.clubtrophies} WHERE clubID={clubid}")
        			#self.cur.execute(f"UPDATE clubs SET trophies={self.clubtrophies} WHERE clubID={clubid}")
        			self.conn.commit()
        			self.conn.close()

    def loadClubName(self, clubid):
        self.conn = sql.connect("Database/clubs.db")
        self.cur = self.conn.cursor()

        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={clubid}")
        fetch = self.cur.fetchall()
        if len(fetch)>0:
        		for i in fetch:
        			self.clubName = i[1]
        		self.conn.commit()
        		self.conn.close()

    def AddMember(self, AllianceID, PlayerID, PlayerName, Action):
        self.conn = sql.connect("Database/clubs.db")
        self.con = sql.connect(f"Database/Chats/{AllianceID}.db")
        self.cur= self.conn.cursor()
        self.chat = self.con.cursor()
        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={AllianceID}")
        fetch = self.cur.fetchall()
        if len(fetch)>0:
        	data = json.loads(fetch[0][8])
        	if Action == 0:
        		self.chat.execute(f"DELETE FROM chats")
        		self.cur.execute(f"DELETE FROM clubs WHERE clubID={AllianceID}")
        		self.con.commit()
        		self.conn.commit()
        		os.remove(f"Database/Chats/{AllianceID}.db")
        	elif Action == 1:
        	   data["members"][str(PlayerID)] = PlayerName
        	   self.cur.execute(f"UPDATE clubs SET members=? WHERE clubID=?",(json.dumps(data),AllianceID))
        	   ol = fetch[0][7]
        	   self.cur.execute(f"UPDATE clubs SET trophies={ol+self.player.trophies} WHERE clubID={AllianceID}")
        	   self.conn.commit()
        	elif Action == 2:
        	       data['members'].pop(str(PlayerID))
        	       self.cur.execute(f"UPDATE clubs SET members=? WHERE clubID=?", (json.dumps(data), AllianceID))
        	       ol = fetch[0][7]
        	       self.cur.execute(f"UPDATE clubs SET trophies={ol-self.player.trophies} WHERE clubID={AllianceID}")
        	       self.conn.commit()
        	self.con.close()
        	self.conn.close()

    def GetMemberData(self, Low_id):
        try:
            self.players = DataBase.loadMembersById(self, Low_id)
            if self.players[4] == int(Low_id):
                    self.lowplrid = self.players[4]
                    self.plrrole = self.players[7]
                    self.plrtrophies = self.players[19]
                    self.plrname = self.players[2]
                    self.plricon = self.players[21]
                    self.plrnamecolor = self.players[22]
                    self.plrexperience = self.players[8]
                    self.plrstatus = self.players[37]

        except Exception as e:
            self.lowplrid = 1
            self.plrrole = 1
            self.plrtrophies = 0
            self.plrname = "Falied to load account!"
            self.plricon = 0
            self.plrnamecolor = 0
            self.plrexperience = 999
            self.plrstatus = 0

    def replaceClubValue(self, target, inf1, inf2, inf3, inf4):
        self.conn = sql.connect("Database/clubs.db")
        self.cur= self.conn.cursor()
        query = Query()
        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={self.player.club_low_id}")
        if 1==1:
        	
        	self.cur.execute(f"UPDATE clubs SET description='{inf1}' WHERE clubID={self.player.club_low_id}")
        	self.cur.execute(f"UPDATE clubs SET badgeID={inf2} WHERE clubID={self.player.club_low_id}")
        	self.cur.execute(f"UPDATE clubs SET type={inf3} WHERE clubID={self.player.club_low_id}")
        	self.cur.execute(f"UPDATE clubs SET trophiesneeded={inf4} WHERE clubID={self.player.club_low_id}")
        	
        	self.conn.commit()
        	self.conn.close()

    def GetmsgCount(self, clubID):
        self.con = sql.connect(f"Database/Chats/{clubID}.db")
        self.chat = self.con.cursor()
        self.chat.execute(f"SELECT * FROM chats")
        fetch = self.chat.fetchall()
        if len(fetch)>0:
        	self.MessageCount = len(fetch)
        else:
        	self.MessageCount = 1
        self.con.close()

    def Addmsg(self, clubID, event, tick, Low_id, name, role, msg):
        clubid = self.player.club_low_id
        self.con = sql.connect(f"Database/Chats/{clubid}.db")
        self.chat = self.con.cursor()
        self.chat.execute(f"SELECT * FROM chats")
        fetch = self.chat.fetchall()
        sss = "INSERT INTO chats VALUES (?, ?, ?,?,?,?)"
        var = event, len(fetch)+1, Low_id, name, role, msg
        self.chat.execute(sss, var)
        self.con.commit()
        self.con.close()

    def DeleteAllMsg(self, clubID):
        self.con = sql.connect(f"Database/Chats/{clubID}.db")
        self.chat = self.con.cursor()
        self.chat.execute(f"SELECT * FROM chats")
        fetch = self.chat.fetchall()
        if len(fetch)>=400:
        	self.chat.execute(f"DELETE FROM chats")
        	self.con.commit()

    def GetLeaderboardByBrawler(self, ID):
        con = get_db_path()
        with con.cursor() as cursor:
            cursor.execute("SELECT lowID, name, trophies, profileIcon, namecolor, clubID FROM `players` ORDER BY trophies DESC LIMIT 100")
            return cursor.fetchall()