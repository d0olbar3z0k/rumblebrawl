from Utils.Writer import Writer
import json
from Database.DatabaseManager import DataBase
import sqlite3 as sql

class AllianceChatServerMessage(Writer):

    def __init__(self, client, player, msg_content, clubID, isbot=False):
        super().__init__(client)
        self.msg_content = msg_content
        self.id = 24312
        self.player = player
        self.clubID = clubID
        self.isbot = isbot
        self.client = client

    def encode(self):
        DataBase.GetmsgCount(self, self.clubID)
        clubid = self.player.club_low_id
        self.conn = sql.connect("Database/clubs.db")
        self.con = sql.connect(f"Database/Chats/{clubid}.db")
        self.cur= self.conn.cursor()
        self.chat = self.con.cursor()

        self.chat.execute(f"SELECT * FROM chats")
        fetch = self.chat.fetchall()
        i = fetch[len(fetch)-1]
        if self.isbot == False:
        	self.writeVint(i[0])
        	self.writeVint(0)
        	self.writeVint(len(fetch))
        	self.writeVint(0)
        	self.writeVint(i[2])#plrid
        	self.writeString(i[3])
        	self.writeVint(i[4])
        	self.writeVint(0)
        	self.writeVint(0)
        	if i[0] == 4:
        	    self.writeVint(int(i[5]))#1 = Kicked, 2 = Join request accepted, 3 = Join the club, 4 = Leave the club
        	    self.writeVint(1)
        	    self.writeVint(0)
        	    self.writeVint(i[2])
        	    self.writeString(i[3])
        	else:
        		self.writeString(i[5])
        else:
        	self.writeVint(i[0])
        	self.writeVint(0)
        	self.writeVint(1)
        	self.writeVint(0)
        	self.writeVint(i[2])#plrid
        	self.writeString(i[3])
        	self.writeVint(i[4])
        	self.writeVint(0)
        	self.writeVint(0)
        	self.writeString(i[5])