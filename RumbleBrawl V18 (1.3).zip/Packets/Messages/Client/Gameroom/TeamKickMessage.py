from Utils.Helpers import Helpers
from Utils.Reader import BSMessageReader
from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Gameroom.TeamKickOK import TeamKickOK
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage

class TeamKickMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
    	self.read_Vint()#highID
    	self.low_id = self.read_Vint()#lowID

    def process(self):
    	for i in Helpers.rooms:
            if i["roomID"] == self.player.room_id:
                for player in i["plrs"]:
                    if player['id'] == self.low_id:
                        i['plrs'].remove(player)
                        DataBase.replaceOtherValue(self, self.low_id, "roomID", 0)
                        TeamKickOK(self.client, self.player).sendWithLowID(self.low_id)
                    else:
                        TeamGameroomDataMessage(self.client, self.player).sendWithLowID(player['id'])
                break