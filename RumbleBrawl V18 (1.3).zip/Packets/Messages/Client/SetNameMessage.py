from Packets.Commands.Server.LogicChangeAvatarNameCommand import LogicChangeAvatarNameCommand
from Packets.Messages.Server.Home.AvatarNameChangeFailedMessage import AvatarNameChangeFailedMessage
from Utils.Reader import BSMessageReader


class SetNameMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.username = self.read_string()
        self.state = self.read_Vint()

    def process(self):
        z = [
    "DDos", "DDOS", "Dodos", "d0s", "dd0s", "tutos", "dudozix", "dudozixx", 
    "dudka", "libreserved", "Iibreserved", "anybody", "dud0z1xx", "dudoz1xx", 
    "dud0zixx", "dudoziks", "dudoziks",
    "ddos", "dDos", "ddOs", "ddoS", "Ddos", "DdOs", "DdoS", "DDos", 
    "dDOS", "dDoS", "ddOS", "DDOs", "DDoS", "dDOS", "DDoS", "DDOS", 
    "dodos", "dOdos", "doDos", "dodOs", "dodoS", "Dodos", "DoDos", 
    "DodOs", "DodoS", "DODos", "DoDOS", "DODOs", "DODoS", "DODOs", 
    "DoDOs", "DoDoS", "DODOS",
    "TG", "tg", "Tg", "tG", 
    "telega", "Telega", "TELEGA", "teLEGA", 
    "telegram", "Telegram", "TELEGRAM", "teLEGRAM",
    "telegramm", "Telegramm", "TELEGRAMM", "teLEGRAMM",
    "official", "Official", "OFFICIAL", "off", "Off", "OFF",
    "TELEG", "Teleg", "teleg", "teLEG",
    "TELEGR", "Telegr", "telegr", "teLEGR",
    "telegra", "Telegra", "TELEGRA", "teLEGRa",
    "tel", "Tel", "TEL", "teL",
    "+7", "+8", "+330",
    "ďđð", "òòó",
    "ддос", "тутос", "дд0с", "дудос", "дудосикс", "дудка"
]
        if self.username and not any(word in self.username for word in z):
            if 2 <= len(self.username) <= 20:
                self.player.name = self.username
                LogicChangeAvatarNameCommand(self.client, self.player, self.state).send()
            else:
                AvatarNameChangeFailedMessage(self.client, self.player).send()
        else:
            AvatarNameChangeFailedMessage(self.client, self.player).send()
