from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Alliance.Events.AllianceJoinOkMessage import AllianceJoinOkMessage
from Packets.Messages.Server.Alliance.Events.AllianceLeaveOkMessage import AllianceLeaveOkMessage
from Database.DatabaseManager import DataBase
from Utils.Helpers import Helpers

from Utils.Reader import BSMessageReader
import threading
import time

class Create_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        # ClubID
        self.clubHighID = 0
        self.clubLowID = Helpers.randomClubID(self)

        # Info
        self.clubName           = self.read_string()    # Club name 
        self.clubdescription    = self.read_string()    # Club description

        # Badge
        self.BadgeIdentifier    = self.read_Vint()      # Badge Identifier
        self.clubbadgeID        = self.read_Vint()      # BadgeID

        # Region
        self.RegionIdentifier   = self.read_Vint()      # Region Identifier
        self.clubregionID       = self.read_Vint()      # RegionID 

        # Settings
        self.clubtype           = self.read_Vint()      # Type
        self.clubtrophiesneeded = self.read_Vint()      # Trophy required
        self.clubfriendlyfamily = self.read_Vint()      # Family friendly

    def process(self):
        DataBase.replaceValue(self, 'clubID', self.clubLowID)
        self.player.club_low_id = self.clubLowID
        DataBase.replaceValue(self, 'clubRole', 2)
        self.player.club_role = 2

        # Club creation
        DataBase.createClub(self, self.clubLowID)

        # Club data
        AllianceJoinOkMessage(self.client, self.player).send()
        MyAllianceMessage(self.client, self.player, self.clubLowID).send()
        AllianceStreamMessage(self.client, self.player, self.clubLowID, 0).send()

        z = [
    "DDos", "DDOS", "Dodos", "d0s", "dd0s", "tutos", "dudozix", "dudozixx", 
    "dudka", "libreserved", "Iibreserved", "anybody", "dud0z1xx", "dudoz1xx", 
    "dud0zixx", "dudoziks", "dudoziks",
    "ddos", "dDos", "ddOs", "ddoS", "Ddos", "DdOs", "DdoS", "DDos", 
    "dDOS", "dDoS", "ddOS", "DDOs", "DDoS", "dDOS", "DDoS", "DDOS", 
    "dodos", "dOdos", "doDos", "dodOs", "dodoS", "Dodos", "DoDos", 
    "DodOs", "DodoS", "DODos", "DoDOS", "DODOs", "DODoS", "DODOs", 
    "DoDOs", "DoDoS", "DODOS",
    "TG", "tg", "Tg", "tG", 
    "telega", "Telega", "TELEGA", "teLEGA", 
    "telegram", "Telegram", "TELEGRAM", "teLEGRAM",
    "telegramm", "Telegramm", "TELEGRAMM", "teLEGRAMM",
    "official", "Official", "OFFICIAL", "off", "Off", "OFF",
    "TELEG", "Teleg", "teleg", "teLEG",
    "TELEGR", "Telegr", "telegr", "teLEGR",
    "telegra", "Telegra", "TELEGRA", "teLEGRa",
    "tel", "Tel", "TEL", "teL",
    "+7", "+8", "+330",
    "ďđð", "òòó",
    "ддос", "тутос", "дд0с", "дудос", "дудосикс", "дудка"
]
        if any(word in self.clubName for word in z):
           
            threading.Thread(target=self.send_leave_message_after_delay).start()

    def send_leave_message_after_delay(self):
        time.sleep(0.5) # это сделано чтобы дб не перегружалась при ддосе
        DataBase.loadClub(self, self.player.club_low_id)

        if self.clubmembercount == 1:
            DataBase.AddMember(self, self.player.club_low_id, self.player.low_id, self.player.name, 0)

        else:
            DataBase.AddMember(self, self.player.club_low_id, self.player.low_id, self.player.name, 2)
            DataBase.Addmsg(self, self.player.club_low_id, 4, 0, self.player.low_id, self.player.name, self.player.club_role, 4)

        # Удаление хз не играл крч
        
        AllianceLeaveOkMessage(self.client, self.player).send()
        MyAllianceMessage(self.client, self.player, 0).send()
        for player in self.plrids:
            if player != self.player.low_id:
                AllianceDataMessage(self.client, self.player, 0, self.player.club_low_id).sendWithLowID(player)
                AllianceChatServerMessage(self.client, self.player, 4, self.player.club_low_id).sendWithLowID(player)

        DataBase.replaceValue(self, 'clubID', 0)
        self.player.club_low_id = 0
        DataBase.replaceValue(self, 'clubRole', 0)
        self.player.club_role = 0