from Utils.Writer import Writer


class LogicTicketsDataCommand(Writer):
    def __init__(self, client, player, count):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.count = count

    def encode(self):
        self.writeVint(203)
        self.writeVint(0)
        self.writeVint(1)
        self.writeVint(100)
        self.writeVint(1)
        self.writeVint(self.count)
        self.writeScId(0, 3)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(self.player.trophy_road)