from Utils.Reader import BSMessageReader
from Database.DatabaseManager import DataBase
from Packets.Commands.Server.ShopResponse import ShopResponse
from Packets.Commands.Server.LogicSkinDataCommand import LogicSkinDataCommand


class LogicViewNotificationCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.a = self.read_Vint()
        self.b = self.read_Vint()
        self.c = self.read_Vint()
        self.d = self.read_Vint()
        self.notif = self.read_Vint()


    def process(self):
        if self.notif == 228228:
            ShopResponse(self.client, self.player, 0, {"id": 8}, self.player.notifgems).send()
            self.player.gems += self.player.notifgems
            self.player.Notifications = "none"
            self.player.notifgems = 0
            DataBase.replaceValue(self, 'Notifications', self.player.Notifications)
            DataBase.replaceValue(self, 'gems', self.player.gems)
            DataBase.replaceValue(self, 'notifgems',  self.player.notifgems)
            DataBase.loadAccount(self)
            print("урааа")
        if self.notif == 228229:
            LogicSkinDataCommand(self.client, self.player, 52).send()
            print("урааа")

        if self.notif == 228227:
            LogicSkinDataCommand(self.client, self.player, 59).send()
            print("урааа")

        if self.notif == 2281337:
            self.add = int(self.player.tickets / 2)
            self.player.gems += self.add
            self.player.tickets = 0
            DataBase.replaceValue(self, 'tickets', self.player.tickets)
            DataBase.replaceValue(self, 'gems', self.player.gems)
            ShopResponse(self.client, self.player, 0, {"id": 8}, self.add).send()
       