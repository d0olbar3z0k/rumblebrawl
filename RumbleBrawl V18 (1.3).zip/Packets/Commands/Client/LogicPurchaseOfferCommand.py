from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.Commands.Server.LogicSkinDataCommand import LogicSkinDataCommand
from Packets.Commands.Server.LogicBrawlerDataCommand import LogicBrawlerDataCommand
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Database.DatabaseManager import DataBase
from Logic.Shop import Shop
from Packets.Commands.Server.ShopResponse import ShopResponse

from Utils.Reader import BSMessageReader

class LogicPurchaseOfferCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.offer_index = self.read_Vint()
        self.brawlerID = self.read_Vint()

    def process(self):
        Shop.loadOffers(self)
        offers = self.offers
        id = offers[self.offer_index]['ID']
        type = offers[self.offer_index]['ShopType']
        cost = offers[self.offer_index]['Cost']
        brawlerID = offers[self.offer_index]['BrawlerID']
        count = offers[self.offer_index]['Multiplier']
        skinID = offers[self.offer_index]['SkinID']

        def res(type):
            if type == 0 or type == 2:
                newGems = self.player.gems - cost
                self.player.gems = newGems
                DataBase.replaceValue(self, 'gems', newGems)
                DataBase.loadAccount(self)
            elif type == 1:
                self.player.gold -= cost
                DataBase.replaceValue(self, 'gold', self.player.gold)
                DataBase.loadAccount(self)
            elif type == 3:
                newStarPoints = self.player.star_points - cost
                self.player.star_points = newStarPoints
                DataBase.replaceValue(self, 'starpoints', newStarPoints)
                DataBase.loadAccount(self)

        if id in [0, 6, 10, 14]:

            if id in [0, 6]:
                self.player.box_id = 5

            elif id == 14:
                self.player.box_id = 4

            elif id == 10:
                self.player.box_id = 3

            res(type)

            if self.player.low_id in offers[self.offer_index]['WhoBuyed']:
                pass
            else:
               

                LogicBoxDataCommand(self.client, self.player, 0, count).send()


                Shop.UpdateOfferData(self, self.offer_index)
            
        elif id == 16:
            Shop.UpdateOfferData(self, self.offer_index)
            ShopResponse(self.client, self.player, 0, {"id": 8}, count).send()
            self.player.gems += count
            DataBase.replaceValue(self, 'gems', self.player.gems)

        elif id == 12:
            Shop.UpdateOfferData(self, self.offer_index)
            ShopResponse(self.client, self.player, 0, {"id": 6, "scid": self.brawlerID}, count).send()
            self.player.brawlers_upgradium[str(self.brawlerID)] += count
            DataBase.replaceValue(self, 'brawlersUpgradePoints', self.player.brawlers_upgradium)

        elif id == 9:
            Shop.UpdateOfferData(self, self.offer_index)
            ShopResponse(self.client, self.player, 0, {"id": 2}, count).send()
            self.player.tokensdoubler += count
            DataBase.replaceValue(self, 'tokensdoubler', self.player.tokensdoubler)

        elif id == 1:
            Shop.UpdateOfferData(self, self.offer_index)
            ShopResponse(self.client, self.player, 0, {"id": 7}, count).send()
            self.player.gold += count
            DataBase.replaceValue(self, 'gold', self.player.gold)

        elif id == 8:
            Shop.UpdateOfferData(self, self.offer_index)
            ShopResponse(self.client, self.player, 0, {"id": 6, "scid": brawlerID}, count).send()
            self.player.brawlers_upgradium[str(brawlerID)] += count
            DataBase.replaceValue(self, 'brawlersUpgradePoints', self.player.brawlers_upgradium)

        elif id == 4:
            LogicSkinDataCommand(self.client, self.player, skinID).send()
            Shop.UpdateOfferData(self, self.offer_index)
        elif id == 3:
            LogicBrawlerDataCommand(self.client, self.player, brawlerID, 0).send()
            Shop.UpdateOfferData(self, self.offer_index)
        else:
            OutOfSyncMessage(self.client, self.player, f'Claiming offer with type {id} is not supported yet').send()

